# TALLBMDeconv

Atlas-guided deconvolution for paediatric T-ALL bone marrow. This package manages
references, invokes the frozen BayesPrism initial-allocation workflow, handles
optional audited flow observations, and returns composition, within-group
expression, RNA-source matrices and patient-level validation.

## Install

Use R >=4.1 and a C++ compiler (Rtools on Windows). First install the real upstream
BayesPrism 2.2.3 and its CRAN/Bioconductor dependencies:

```r
install.packages(c("remotes", "BiocManager"))
BiocManager::install(c("scran", "BiocParallel"))
remotes::install_github("Danko-Lab/BayesPrism/BayesPrism")
# Check packageVersion("BayesPrism") == "2.2.3" for this audited release.
install.packages("TALLBMDeconv_0.1.1.tar.gz", repos = NULL, type = "source")
```

The authorised internal distribution includes two separately versioned atlas
resources and donor aggregates. The public-code distribution omits patient-derived
references until their redistribution is cleared. It accepts custom references;
loading the default without its authorised resource gives an explicit error.
Reference permissions are described in `inst/REFERENCE_LICENSE.md`, separately
from GPL-3 code licensing. No upload of private data is performed by the package.

## Ready to use

```r
library(TALLBMDeconv)
reference <- tall_load_reference()  # fullAtlas81 deployment resource
result <- tall_deconv(bulk_counts, reference = reference, out_dir = "run_v1")
composition <- tall_extract(result, "composition_rna")
malignant <- tall_extract(result, "expression", "Malignant_total",
                          genes = c("HOXA9", "CD3D"))
sources <- tall_extract(result, "rna_source_fraction", "Malignant_total")
tall_qc(result)
tall_verify(result$path)
```

`bulk_counts` is a **genes x patients raw integer count matrix**, with unique
gene symbols and patient IDs. TPM, logarithms, duplicate IDs, zero libraries and
missing reference genes are rejected. Counts must be declared as raw; integer
rounding alone cannot establish their provenance. Ensembl input is supported via
the supplied unique symbol dictionary with an explicit mapping audit. Missing
genes are never filled with zero. Build a new, explicitly gene-matched reference
when necessary rather than silently changing the validated gene universe.

## What is measured?

* **RNA composition:** posterior mean allocated reads divided by the modeled
  sample library, not the mean latent theta and not a measured cell percentage.
* **Cell proxy:** divide each fine-state RNA contribution by its donor-equal,
  gene-matched RNA-per-cell reference value, normalise, then aggregate. It is an
  estimated conversion, not a replacement for matched flow counts.
* **Within-group expression:** CPM of reads allocated to that group on the
  modeled gene universe. Zero allocated mass produces **NA**, not zeros or a
  fabricated reference expression profile.
* **Contribution:** group CPM x group RNA contribution. Coarse contributions
  sum to modeled bulk CPM. Per-gene source fractions sum to one where expressed;
  zero-total genes have undefined source fractions.
* **Malignant L1:** 12 fine components sum to malignant total in the same fit.
  Whole-sample and within-malignant proportions are separate outputs. L2/L3
  labels remain reference metadata; the package does not claim to estimate them.

Normal T in the historical 125 release has zero allocated mass despite a positive
reference. Its expression remains NA. No biological absence is inferred.

## Optional flow: observations, not post-hoc rescaling

```r
flow <- data.frame(
  sample_id = "patient1", group = "Malignant_total", kind = "lower",
  lower = 0.60, measurement_error = 0.03,
  denominator_scope = "modeled_nucleated",
  original_denominator = "audited all-nucleated parent",
  gate_identity = "clinical abnormal population")
constrained <- tall_add_flow(result, flow, out_dir = "run_flow_v1")
```

Use `point` with `value`, `lower` with `lower`, or `interval` with `lower/upper`.
Fractions are 0--1. `unknown` is retained but has no likelihood term; a measured
zero is a point at zero. Missing populations and patients remain unconstrained.
The existing audited adapter applies a soft Huber observation likelihood during
inference, using gene-matched sizes to map RNA to cell space. It does not replace
lower bounds by point values. Conditional lymphocyte-parent percentages are
rejected unless independently converted to an audited supported denominator.
The conservative raw-event denominator is accepted only for lower bounds.
Original denominator and gate identity are mandatory and retained in the audit.
The software cannot establish specimen or gating validity from a table alone.

Each result records which patients actually used observations. Adding flow creates
a **new fit and new directory**; it never edits a finished no-flow result.
`config=list(flow_strength=0)` disables the flow likelihood and records observations
as requested but unused. Patients with no flow rows are fitted without constraints.

## Custom reference

```r
annotations <- data.frame(cell_id = colnames(reference_counts), group = cell_type)
custom <- tall_build_reference(reference_counts, annotations, donor_ids,
                               reference_id = "my_reference_v1")
result <- tall_deconv(bulk_counts, custom, out_dir = "custom_run_v1")
```

`donor_ids` can be named by cell ID. `coarse_group`, `compartment`, `role` and
L1/L2/L3 annotation columns are optional. No T-ALL-specific hierarchy is required.
No clustering or classifier retraining occurs. Custom references do not inherit
the project's benchmark results.

## Paired patient-level benchmark

```r
truth <- list(counts = paired_sc_counts,
              cell_annotations = paired_annotations, patient_ids = sc_donor_ids)
validation <- tall_benchmark(paired_bulk, truth, custom, split = "holdout",
                              out_dir = "paired_validation_v1")
```

`independent` rejects any training/validation patient overlap. `holdout` excludes
all validation patients at once. `lopo` excludes the evaluated patient. Patient
aliases are resolved using the declared reference mapping; no random cell split
is substituted. If exclusion removes all reference cells of a group, the call stops explicitly;
define a new eligible reference rather than filling its estimate with zero. The default atlas's optional donor resource is
required for rebuilding patient-split references. Existing fits can be supplied
through `results` if their reference members, parameters and modeled bulk counts
match the requested split and input. If `flow` is supplied too, its effective
observations must match the imported fit. Supplying flow does not retrofit a
no-flow fit; first create that fit with `tall_add_flow`. Missing supplied fits or
expression files raise errors rather than triggering a hidden refit or biological
missingness result. Raw truth requires unique cell IDs and donor mappings.
Present pseudobulk truth includes all model genes/groups; confirmed absence has
explicit zero counts. Source availability is a named TRUE/FALSE vector.
`truth_coverage.tsv` records actual patient coverage.

Outputs separate RNA/cell-proxy composition, expression recovery, coverage,
reference-mean RMSE, and patient-specific correlations/variation. Expression
truth defaults to >=20 cells; composition can contain real zeros. Missing truth
or recovered expression is not scored as zero. Input flow gates are labelled
calibration, not independent composition validation. Genes are not treated as
independent patients. Malignant expression truth in the historical heldout9 is
N=7, not 9: 288 lacks qualified malignant truth; 291 lacks an included truth source.

## Versioning and reproducibility

* `TALL_BM_benchmark73_v1.0.0`: historical9 overall-heldout reference; fixed125
  release uses this resource. Source patients present8, malignant expression7.
* `TALL_BM_fullAtlas81_v1.0.0`: full eligible deployment reference; no inherited
  independent9 validation claim. Separate resource hash and ID.
* Default algorithm: BayesPrism2.2.3 fixed-phi **initial allocation only**;
  2 chains, seeds123/20261110, 40000 iterations, burn-in20000, retain20004 through
  40000 every4. No reference update. C++ execution is tested against the real
  exported upstream sampler and historical frozen fits.
  Each sampler call fixes Mersenne-Twister/Inversion/Rejection and restores the
  caller RNG kind and seed, independently of sample order.
* Outputs are versioned directories; existing results are never overwritten.
  SHA256, reference hashes, input IDs, gene mapping, config and R session are saved.
* Low-contribution flags are descriptive. Theta intervals are not expression
  uncertainty; between-chain expression differences are diagnostics, not credible
  intervals or donor-bootstrap uncertainty.

BLADE and MuSiC remain preserved historical comparison results. This first package
does **not** advertise unimplemented production backends or rerun their benchmarks.
The reference/result schema separates the engine from downstream extraction and
QC so an audited additional engine can be added later.

## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE, comment="#>")
library(TALLBMDeconv)

## -----------------------------------------------------------------------------
x <- matrix(c(20,3,6,1, 2,18,1,7, 19,4,7,2, 3,17,2,8), nrow=4)
rownames(x) <- paste0("g",1:4)
colnames(x) <- paste0("cell",1:4)
a <- data.frame(cell_id=colnames(x), group=c("A","B","A","B"))
ref <- tall_build_reference(x,a,c("donor1","donor1","donor2","donor2"),"example_v1")
bulk <- cbind(validation_patient=rowSums(x))
result <- tall_deconv(bulk,ref,config=list(iterations=400L,burnin=200L,thin=4L))
tall_extract(result)
tall_extract(result,"expression","A")
tall_qc(result)

